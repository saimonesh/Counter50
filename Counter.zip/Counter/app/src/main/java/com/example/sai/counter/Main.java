package com.example.sai.counter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main extends AppCompatActivity {
    int clicked=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView text= (TextView) findViewById(R.id.tex);
        final Button but=(Button) findViewById(R.id.but);
        if (text != null) {
            text.setText("Button not clicked");
        }
        if (but != null) {
            but.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(clicked==50)
                    {
                        clicked=0;
                    }
                    else {
                        clicked++;
                        text.setText("clicked" + clicked);
                    }
                }
            });
        }
    }
}
